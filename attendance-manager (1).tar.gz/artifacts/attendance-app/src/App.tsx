import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { setAuthTokenGetter } from "@workspace/api-client-react";
import { AuthProvider, useAuth } from "./hooks/use-auth";
import NotFound from "@/pages/not-found";
import { Layout } from "@/components/layout";

import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import Attendance from "@/pages/attendance";
import Members from "@/pages/members";
import Export from "@/pages/export";
import Report from "@/pages/report";

const queryClient = new QueryClient();

// Register the token getter for Orval hooks
setAuthTokenGetter(() => localStorage.getItem("attendance_token"));

function ProtectedRoute({ component: Component, adminOnly = false }: { component: any, adminOnly?: boolean }) {
  const { token, member, isLoading } = useAuth();

  if (isLoading) return <div className="p-8 text-center">Loading...</div>;
  if (!token || !member) return <Redirect to="/login" />;
  if (adminOnly && member.role !== "admin") return <Redirect to="/dashboard" />;

  return (
    <Layout>
      <Component />
    </Layout>
  );
}

function Router() {
  const { token, isLoading } = useAuth();

  return (
    <Switch>
      <Route path="/login">
        {() => {
          if (isLoading) return <div className="p-8 text-center">Loading...</div>;
          if (token) return <Redirect to="/dashboard" />;
          return <Login />;
        }}
      </Route>
      <Route path="/dashboard"><ProtectedRoute component={Dashboard} /></Route>
      <Route path="/attendance"><ProtectedRoute component={Attendance} /></Route>
      <Route path="/members"><ProtectedRoute component={Members} adminOnly /></Route>
      <Route path="/export"><ProtectedRoute component={Export} adminOnly /></Route>
      <Route path="/report"><ProtectedRoute component={Report} adminOnly /></Route>
      <Route path="/"><Redirect to="/dashboard" /></Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
        </AuthProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
