import { format } from "date-fns";

export function getCurrentMonthYear() {
  const now = new Date();
  return {
    month: now.getMonth() + 1,
    year: now.getFullYear(),
  };
}

export function formatYearMonth(year: number, month: number) {
  return format(new Date(year, month - 1), "MMMM yyyy");
}
