import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import {
  useGetAdminStats,
  useGetMemberStats,
  getGetAdminStatsQueryKey,
  getGetMemberStatsQueryKey,
} from "@workspace/api-client-react";
import { getCurrentMonthYear, formatYearMonth } from "@/lib/date-utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Users, UserCheck, UserX, Activity, Trophy, ChevronLeft, ChevronRight,
  TrendingUp, Calendar, CheckCircle2, XCircle, Clock
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, LineChart, Line, AreaChart, Area
} from "recharts";

export default function Dashboard() {
  const { member } = useAuth();
  const isAdmin = member?.role === "admin";

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground text-sm">
          {isAdmin ? "Live overview of all member attendance" : `Welcome back, ${member?.name}`}
        </p>
      </div>
      {isAdmin ? <AdminDashboard /> : <MemberDashboard />}
    </div>
  );
}

/* ─── Admin Dashboard ─────────────────────────────────────────────────── */
function AdminDashboard() {
  const now = new Date();
  const [date, setDate] = useState({ month: now.getMonth() + 1, year: now.getFullYear() });
  const isCurrentMonth = date.month === now.getMonth() + 1 && date.year === now.getFullYear();

  const { data: stats, isLoading } = useGetAdminStats(
    { month: date.month, year: date.year },
    { query: { queryKey: getGetAdminStatsQueryKey({ month: date.month, year: date.year }) } }
  );

  const handlePrev = () => setDate(p => p.month === 1 ? { month: 12, year: p.year - 1 } : { month: p.month - 1, year: p.year });
  const handleNext = () => setDate(p => p.month === 12 ? { month: 1, year: p.year + 1 } : { month: p.month + 1, year: p.year });

  const todayAttendanceRate = stats && stats.totalScheduledToday > 0
    ? Math.round((stats.todayPresent / stats.totalScheduledToday) * 100)
    : 0;

  const trendData = (stats?.monthlyTrend ?? []).filter(d => {
    if (!isCurrentMonth) return true;
    return new Date(d.date).getDate() <= now.getDate();
  });

  return (
    <div className="space-y-6">
      {/* Month Selector */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1 border rounded-lg p-1 bg-card w-fit">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handlePrev}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-sm font-semibold px-3 min-w-[130px] text-center">
            {formatYearMonth(date.year, date.month)}
          </span>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleNext}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        {isCurrentMonth && (
          <Badge variant="outline" className="gap-1.5 border-emerald-300 text-emerald-700 bg-emerald-50">
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse inline-block" />
            Live
          </Badge>
        )}
      </div>

      {/* Top Stat Cards */}
      {isLoading ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-28" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="border-l-4 border-l-primary">
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-muted-foreground font-medium">Total Members</span>
                <Users className="h-4 w-4 text-muted-foreground" />
              </div>
              <p className="text-3xl font-bold">{stats?.totalMembers ?? 0}</p>
              <p className="text-xs text-muted-foreground mt-1">
                G1: {stats?.group1Count ?? 0} · G2: {stats?.group2Count ?? 0}
              </p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-blue-500">
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-muted-foreground font-medium">Monthly Rate</span>
                <Activity className="h-4 w-4 text-blue-500" />
              </div>
              <p className={`text-3xl font-bold ${
                (stats?.monthlyPresentRate ?? 0) >= 75 ? "text-emerald-600" :
                (stats?.monthlyPresentRate ?? 0) >= 50 ? "text-amber-600" : "text-rose-600"
              }`}>{stats?.monthlyPresentRate ?? 0}%</p>
              <p className="text-xs text-muted-foreground mt-1">Overall present rate</p>
            </CardContent>
          </Card>

          <Card className={`border-l-4 ${isCurrentMonth ? "border-l-emerald-500" : "border-l-muted"}`}>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-muted-foreground font-medium">
                  {isCurrentMonth ? "Today Present" : "Last Recorded"}
                </span>
                <UserCheck className="h-4 w-4 text-emerald-500" />
              </div>
              <p className="text-3xl font-bold text-emerald-600">{stats?.todayPresent ?? 0}</p>
              {isCurrentMonth && stats && (
                <div className="mt-2">
                  <Progress value={todayAttendanceRate} className="h-1.5" />
                  <p className="text-xs text-muted-foreground mt-1">{todayAttendanceRate}% of {stats.totalScheduledToday} scheduled</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-rose-500">
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-muted-foreground font-medium">
                  {isCurrentMonth ? "Today Absent" : "–"}
                </span>
                <UserX className="h-4 w-4 text-rose-500" />
              </div>
              <p className="text-3xl font-bold text-rose-600">{stats?.todayAbsent ?? 0}</p>
              <p className="text-xs text-muted-foreground mt-1">
                {isCurrentMonth ? "Marked absent today" : "No data"}
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Group Progress Cards */}
      {!isLoading && stats && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Card>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="font-semibold text-sm">Group 1</p>
                  <p className="text-xs text-muted-foreground">Mon · Wed · Sat</p>
                </div>
                <Badge variant="outline">{stats.group1Count} members</Badge>
              </div>
              <div className="flex items-center gap-3">
                <Progress value={stats.group1PresentRate} className="flex-1 h-3" />
                <span className={`text-lg font-bold min-w-[44px] text-right ${
                  stats.group1PresentRate >= 75 ? "text-emerald-600" :
                  stats.group1PresentRate >= 50 ? "text-amber-600" : "text-rose-600"
                }`}>{stats.group1PresentRate}%</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="font-semibold text-sm">Group 2</p>
                  <p className="text-xs text-muted-foreground">Tue · Thu · Sun</p>
                </div>
                <Badge variant="outline">{stats.group2Count} members</Badge>
              </div>
              <div className="flex items-center gap-3">
                <Progress value={stats.group2PresentRate} className="flex-1 h-3" />
                <span className={`text-lg font-bold min-w-[44px] text-right ${
                  stats.group2PresentRate >= 75 ? "text-emerald-600" :
                  stats.group2PresentRate >= 50 ? "text-amber-600" : "text-rose-600"
                }`}>{stats.group2PresentRate}%</span>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Leaderboard + Trend Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Leaderboard */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Trophy className="h-4 w-4 text-amber-500" />
              Attendance Leaderboard
            </CardTitle>
            <p className="text-xs text-muted-foreground">{formatYearMonth(date.year, date.month)}</p>
          </CardHeader>
          <CardContent className="space-y-3 pb-4">
            {isLoading ? (
              [1,2,3,4,5].map(i => <Skeleton key={i} className="h-12 w-full" />)
            ) : !stats?.leaderboard?.length ? (
              <p className="text-sm text-muted-foreground py-4 text-center">No attendance data yet</p>
            ) : (
              stats.leaderboard.map((entry, idx) => (
                <div key={entry.userId} className="flex items-center gap-3">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0
                    ${idx === 0 ? "bg-amber-100 text-amber-700 border border-amber-300" :
                      idx === 1 ? "bg-slate-100 text-slate-600 border border-slate-300" :
                      idx === 2 ? "bg-orange-100 text-orange-700 border border-orange-300" :
                      "bg-muted text-muted-foreground"}`}>
                    {idx + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium truncate">{entry.name}</span>
                      <span className={`text-sm font-bold ml-2 shrink-0 ${
                        entry.attendancePercentage >= 75 ? "text-emerald-600" :
                        entry.attendancePercentage >= 50 ? "text-amber-600" : "text-rose-600"
                      }`}>{entry.attendancePercentage}%</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Progress value={entry.attendancePercentage} className="h-1.5 flex-1" />
                      <span className="text-xs text-muted-foreground shrink-0">
                        {entry.totalPresent}/{entry.totalScheduled}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>

        {/* Monthly Trend Chart */}
        <Card className="lg:col-span-3">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="h-4 w-4 text-blue-500" />
              Monthly Attendance Trend
            </CardTitle>
            <p className="text-xs text-muted-foreground">{formatYearMonth(date.year, date.month)}</p>
          </CardHeader>
          <CardContent className="h-[280px] pr-2">
            {isLoading ? <Skeleton className="h-full w-full" /> : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trendData} margin={{ top: 5, right: 10, left: -25, bottom: 5 }}>
                  <defs>
                    <linearGradient id="presentGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(142, 76%, 36%)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(142, 76%, 36%)" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="absentGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(0, 84%, 60%)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(0, 84%, 60%)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis dataKey="date" tickFormatter={(val) => new Date(val).getDate().toString()} tick={{ fontSize: 11 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                  <Tooltip
                    labelFormatter={(val) => new Date(val).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}
                    contentStyle={{ fontSize: 12, borderRadius: 8 }}
                  />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Area type="monotone" dataKey="present" name="Present" stroke="hsl(142, 76%, 36%)" fill="url(#presentGrad)" strokeWidth={2} />
                  <Area type="monotone" dataKey="absent" name="Absent" stroke="hsl(0, 84%, 60%)" fill="url(#absentGrad)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* End of Month Summary */}
      {!isLoading && stats && (stats.leaderboard?.length ?? 0) > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Month Summary — {formatYearMonth(date.year, date.month)}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted/60 border-b">
                    <th className="px-4 py-3 text-left font-semibold">Member</th>
                    <th className="px-3 py-3 text-center font-semibold">Group</th>
                    <th className="px-3 py-3 text-center font-semibold text-emerald-700">Present</th>
                    <th className="px-3 py-3 text-center font-semibold text-muted-foreground">Scheduled</th>
                    <th className="px-3 py-3 text-center font-semibold">Rate</th>
                    <th className="px-3 py-3 text-center font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {stats.leaderboard.map((entry) => (
                    <tr key={entry.userId} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3 font-medium">{entry.name}</td>
                      <td className="px-3 py-3 text-center">
                        <Badge variant="outline" className="text-xs">G{entry.group}</Badge>
                      </td>
                      <td className="px-3 py-3 text-center font-bold text-emerald-600">{entry.totalPresent}</td>
                      <td className="px-3 py-3 text-center text-muted-foreground">{entry.totalScheduled}</td>
                      <td className="px-3 py-3 text-center">
                        <span className={`font-bold ${
                          entry.attendancePercentage >= 75 ? "text-emerald-600" :
                          entry.attendancePercentage >= 50 ? "text-amber-600" : "text-rose-600"
                        }`}>{entry.attendancePercentage}%</span>
                      </td>
                      <td className="px-3 py-3 text-center">
                        {entry.totalScheduled === 0 ? (
                          <Badge variant="outline" className="text-xs text-muted-foreground">No data</Badge>
                        ) : entry.attendancePercentage >= 75 ? (
                          <Badge className="bg-emerald-100 text-emerald-800 border border-emerald-300 hover:bg-emerald-100 text-xs">Excellent</Badge>
                        ) : entry.attendancePercentage >= 50 ? (
                          <Badge className="bg-amber-100 text-amber-800 border border-amber-300 hover:bg-amber-100 text-xs">Average</Badge>
                        ) : (
                          <Badge className="bg-rose-100 text-rose-800 border border-rose-300 hover:bg-rose-100 text-xs">Poor</Badge>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

/* ─── Member Dashboard ───────────────────────────────────────────────── */
const GROUP_DAYS: Record<number, number[]> = {
  1: [1, 3, 6],
  2: [2, 4, 0],
};

function MemberDashboard() {
  const { member } = useAuth();
  const now = new Date();
  const [date, setDate] = useState({ month: now.getMonth() + 1, year: now.getFullYear() });

  const { data: stats, isLoading } = useGetMemberStats(
    { month: date.month, year: date.year },
    { query: { queryKey: getGetMemberStatsQueryKey({ month: date.month, year: date.year }) } }
  );

  const handlePrev = () => setDate(p => p.month === 1 ? { month: 12, year: p.year - 1 } : { month: p.month - 1, year: p.year });
  const handleNext = () => setDate(p => p.month === 12 ? { month: 1, year: p.year + 1 } : { month: p.month + 1, year: p.year });

  const isCurrentMonth = date.month === now.getMonth() + 1 && date.year === now.getFullYear();

  // Build calendar data
  const daysInMonth = new Date(date.year, date.month, 0).getDate();
  const group = member?.group ?? 1;
  const groupDays = GROUP_DAYS[group] ?? [];

  const attendanceMap: Record<string, "P" | "A"> = {};
  stats?.monthlyBreakdown.forEach(r => { attendanceMap[r.date] = r.status; });

  const calendarDays = Array.from({ length: daysInMonth }, (_, i) => {
    const day = i + 1;
    const dateObj = new Date(date.year, date.month - 1, day);
    const dateStr = `${date.year}-${String(date.month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    const isScheduled = groupDays.includes(dateObj.getDay());
    const isPast = dateObj <= now || !isCurrentMonth;
    const status = attendanceMap[dateStr];
    return { day, dateStr, isScheduled, isPast, status, dayName: ["Su","Mo","Tu","We","Th","Fr","Sa"][dateObj.getDay()] };
  });

  // Chart data - only scheduled days with attendance
  const chartData = calendarDays
    .filter(d => d.isScheduled && d.isPast)
    .map(d => ({ day: d.day, value: d.status === "P" ? 1 : d.status === "A" ? 0 : null, status: d.status }));

  const pct = stats?.attendancePercentage ?? 0;

  return (
    <div className="space-y-6">
      {/* Month nav */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1 border rounded-lg p-1 bg-card w-fit">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handlePrev}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-sm font-semibold px-3 min-w-[130px] text-center">
            {formatYearMonth(date.year, date.month)}
          </span>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleNext}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        <Badge variant="outline" className="text-xs">
          Group {group} · {group === 1 ? "Mon/Wed/Sat" : "Tue/Thu/Sun"}
        </Badge>
      </div>

      {isLoading ? <MemberSkeleton /> : (
        <>
          {/* Stats Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Card className="sm:col-span-1 col-span-2 bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
              <CardContent className="pt-5 pb-4 text-center">
                <Activity className="h-5 w-5 text-primary mx-auto mb-2" />
                <p className={`text-4xl font-black ${pct >= 75 ? "text-emerald-600" : pct >= 50 ? "text-amber-600" : "text-rose-600"}`}>
                  {pct}%
                </p>
                <p className="text-xs text-muted-foreground mt-1">Attendance Rate</p>
                <Badge className={`mt-2 text-xs ${
                  pct >= 75 ? "bg-emerald-100 text-emerald-800 border border-emerald-300 hover:bg-emerald-100" :
                  pct >= 50 ? "bg-amber-100 text-amber-800 border border-amber-300 hover:bg-amber-100" :
                  "bg-rose-100 text-rose-800 border border-rose-300 hover:bg-rose-100"
                }`}>
                  {pct >= 75 ? "Excellent" : pct >= 50 ? "Average" : stats?.totalScheduled === 0 ? "No data" : "Needs improvement"}
                </Badge>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-5 pb-4 text-center">
                <CheckCircle2 className="h-5 w-5 text-emerald-500 mx-auto mb-2" />
                <p className="text-3xl font-bold text-emerald-600">{stats?.totalPresent ?? 0}</p>
                <p className="text-xs text-muted-foreground mt-1">Days Present</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-5 pb-4 text-center">
                <XCircle className="h-5 w-5 text-rose-500 mx-auto mb-2" />
                <p className="text-3xl font-bold text-rose-600">{stats?.totalAbsent ?? 0}</p>
                <p className="text-xs text-muted-foreground mt-1">Days Absent</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-5 pb-4 text-center">
                <Clock className="h-5 w-5 text-blue-500 mx-auto mb-2" />
                <p className="text-3xl font-bold">{stats?.totalScheduled ?? 0}</p>
                <p className="text-xs text-muted-foreground mt-1">Days Scheduled</p>
              </CardContent>
            </Card>
          </div>

          {/* Progress bar */}
          <Card>
            <CardContent className="pt-5 pb-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Monthly Progress</span>
                <span className="text-sm text-muted-foreground">{stats?.totalPresent} / {stats?.totalScheduled} sessions attended</span>
              </div>
              <Progress value={pct} className="h-3" />
              <div className="flex justify-between mt-1.5 text-xs text-muted-foreground">
                <span>0%</span>
                <span className="text-amber-600">50% Average</span>
                <span className="text-emerald-600">75% Excellent</span>
                <span>100%</span>
              </div>
            </CardContent>
          </Card>

          {/* Attendance Calendar */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Attendance Calendar
              </CardTitle>
              <div className="flex items-center gap-4 text-xs text-muted-foreground flex-wrap">
                <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-emerald-500 inline-block" />Present</span>
                <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-rose-400 inline-block" />Absent</span>
                <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-muted inline-block" />Not scheduled</span>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-1.5">
                {["Su","Mo","Tu","We","Th","Fr","Sa"].map(d => (
                  <div key={d} className="text-center text-xs font-semibold text-muted-foreground py-1">{d}</div>
                ))}
                {/* Offset for first day */}
                {Array.from({ length: new Date(date.year, date.month - 1, 1).getDay() }, (_, i) => (
                  <div key={`off-${i}`} />
                ))}
                {calendarDays.map(({ day, isScheduled, isPast, status }) => (
                  <div
                    key={day}
                    className={`
                      aspect-square rounded-lg flex flex-col items-center justify-center text-xs font-medium
                      ${!isScheduled ? "bg-muted/30 text-muted-foreground/40" : ""}
                      ${isScheduled && !isPast ? "border-2 border-dashed border-muted-foreground/20 text-muted-foreground" : ""}
                      ${status === "P" ? "bg-emerald-100 text-emerald-800 border border-emerald-300" : ""}
                      ${status === "A" ? "bg-rose-100 text-rose-700 border border-rose-300" : ""}
                      ${isCurrentMonth && day === now.getDate() ? "ring-2 ring-primary ring-offset-1" : ""}
                    `}
                  >
                    <span>{day}</span>
                    {status === "P" && <span className="text-[9px] leading-none text-emerald-600">P</span>}
                    {status === "A" && <span className="text-[9px] leading-none text-rose-600">A</span>}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Attendance Chart */}
          {chartData.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-blue-500" />
                  Session Attendance — {formatYearMonth(date.year, date.month)}
                </CardTitle>
              </CardHeader>
              <CardContent className="h-[200px] pr-2">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 5, right: 10, left: -25, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                    <XAxis dataKey="day" tick={{ fontSize: 11 }} />
                    <YAxis ticks={[0, 1]} tickFormatter={(v) => v === 1 ? "P" : "A"} tick={{ fontSize: 11 }} />
                    <Tooltip
                      formatter={(v: number) => [v === 1 ? "Present" : "Absent", "Status"]}
                      labelFormatter={(v) => `Day ${v}`}
                      contentStyle={{ fontSize: 12, borderRadius: 8 }}
                    />
                    <Bar
                      dataKey="value"
                      radius={[4, 4, 0, 0]}
                      fill="hsl(142, 76%, 36%)"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}

function MemberSkeleton() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[1,2,3,4].map(i => <Skeleton key={i} className="h-28" />)}
      </div>
      <Skeleton className="h-16 w-full" />
      <Skeleton className="h-64 w-full" />
    </div>
  );
}
