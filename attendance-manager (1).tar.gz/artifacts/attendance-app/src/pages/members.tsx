import { useState } from "react";
import {
  useListMembers,
  useCreateMember,
  useDeleteMember,
  getListMembersQueryKey,
  ListMembersGroup,
  CreateMemberBodyGroup,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";
import { Search, Plus, Trash2, KeyRound, Copy, Check, Users } from "lucide-react";
import { format } from "date-fns";

const createSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  group: z.string(),
});

function CredentialsDisplay({ userId, plainPassword, onDone }: {
  userId: string; plainPassword: string; onDone: () => void;
}) {
  const [copiedId, setCopiedId] = useState(false);
  const [copiedPwd, setCopiedPwd] = useState(false);

  const copy = async (text: string, which: "id" | "pwd") => {
    await navigator.clipboard.writeText(text);
    if (which === "id") { setCopiedId(true); setTimeout(() => setCopiedId(false), 1500); }
    else { setCopiedPwd(true); setTimeout(() => setCopiedPwd(false), 1500); }
  };

  return (
    <div className="space-y-4 py-2">
      <div className="rounded-lg border bg-muted/40 p-4 space-y-3">
        <p className="text-sm font-semibold flex items-center gap-2">
          <KeyRound className="h-4 w-4 text-primary" />
          Save these credentials — they won't be shown again!
        </p>
        <div className="space-y-2">
          {[
            { label: "User ID", value: userId, which: "id" as const, copied: copiedId },
            { label: "Password", value: plainPassword, which: "pwd" as const, copied: copiedPwd },
          ].map(({ label, value, which, copied }) => (
            <div key={label} className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground w-20 shrink-0">{label}:</span>
              <code className="flex-1 bg-background border rounded px-2 py-1 text-sm font-mono">{value}</code>
              <Button
                variant="ghost" size="icon" className="h-7 w-7 shrink-0"
                onClick={() => copy(value, which)}
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
              </Button>
            </div>
          ))}
        </div>
      </div>
      <DialogFooter>
        <Button onClick={onDone} className="w-full">Done — I've saved the credentials</Button>
      </DialogFooter>
    </div>
  );
}

function ResetPasswordButton({ member }: { member: { userId: string; name: string } }) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [newCreds, setNewCreds] = useState<{ userId: string; plainPassword: string } | null>(null);
  const { toast } = useToast();

  const handleReset = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem("attendance_token");
      const res = await fetch(`/api/members/${member.userId}/password`, {
        method: "PUT",
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to reset password");
      const data = await res.json();
      setNewCreds({ userId: data.userId, plainPassword: data.plainPassword });
    } catch {
      toast({ variant: "destructive", title: "Reset failed", description: "Could not reset password. Try again." });
      setOpen(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setNewCreds(null); }}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary">
          <KeyRound className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{newCreds ? "New Credentials Ready" : "Reset Password"}</DialogTitle>
          <DialogDescription>
            {newCreds
              ? `New credentials for ${member.name}`
              : `Generate a new random password for ${member.name}. Their current password will stop working immediately.`}
          </DialogDescription>
        </DialogHeader>
        {newCreds ? (
          <CredentialsDisplay
            userId={newCreds.userId}
            plainPassword={newCreds.plainPassword}
            onDone={() => { setOpen(false); setNewCreds(null); }}
          />
        ) : (
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={handleReset} disabled={loading}>
              {loading ? "Resetting..." : "Reset Password"}
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default function Members() {
  const [search, setSearch] = useState("");
  const [groupFilter, setGroupFilter] = useState<"all" | "1" | "2">("all");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [createOpen, setCreateOpen] = useState(false);
  const [newMemberInfo, setNewMemberInfo] = useState<{ userId: string; plainPassword: string } | null>(null);

  const queryParams = {
    ...(search.trim() ? { search: search.trim() } : {}),
    ...(groupFilter !== "all" ? { group: Number(groupFilter) as ListMembersGroup } : {}),
  };

  const { data: members, isLoading } = useListMembers(queryParams, {
    query: { queryKey: getListMembersQueryKey(queryParams) },
  });

  const createMutation = useCreateMember({
    mutation: {
      onSuccess: (data) => {
        setNewMemberInfo({ userId: data.userId, plainPassword: data.plainPassword });
        queryClient.invalidateQueries({ queryKey: getListMembersQueryKey() });
        form.reset();
      },
      onError: (error: any) => {
        toast({ variant: "destructive", title: "Failed to create member", description: error.message });
      },
    },
  });

  const deleteMutation = useDeleteMember({
    mutation: {
      onSuccess: () => {
        toast({ title: "Member deleted successfully" });
        queryClient.invalidateQueries({ queryKey: getListMembersQueryKey() });
      },
      onError: (error: any) => {
        toast({ variant: "destructive", title: "Failed to delete member", description: error.message });
      },
    },
  });

  const form = useForm<z.infer<typeof createSchema>>({
    resolver: zodResolver(createSchema),
    defaultValues: { name: "", group: "1" },
  });

  const onSubmit = (values: z.infer<typeof createSchema>) => {
    createMutation.mutate({ data: { name: values.name, group: Number(values.group) as CreateMemberBodyGroup } });
  };

  const onlyMembers = (members ?? []).filter(m => m.role !== "admin");
  const g1Count = onlyMembers.filter(m => m.group === 1).length;
  const g2Count = onlyMembers.filter(m => m.group === 2).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Members</h2>
          <p className="text-muted-foreground text-sm">Manage member accounts, groups, and credentials.</p>
        </div>
        <Dialog open={createOpen} onOpenChange={(open) => { setCreateOpen(open); if (!open) setNewMemberInfo(null); }}>
          <DialogTrigger asChild>
            <Button><Plus className="mr-2 h-4 w-4" />Add Member</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Member</DialogTitle>
              <DialogDescription>
                A unique User ID and password will be generated automatically. Share these with the member so they can log in.
              </DialogDescription>
            </DialogHeader>
            {newMemberInfo ? (
              <CredentialsDisplay
                userId={newMemberInfo.userId}
                plainPassword={newMemberInfo.plainPassword}
                onDone={() => { setCreateOpen(false); setNewMemberInfo(null); }}
              />
            ) : (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-2">
                  <FormField control={form.control} name="name" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl><Input placeholder="e.g. Sarah Johnson" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="group" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Group</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger><SelectValue placeholder="Select group" /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="1">Group 1 — Mon, Wed, Sat</SelectItem>
                          <SelectItem value="2">Group 2 — Tue, Thu, Sun</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <DialogFooter>
                    <Button variant="outline" type="button" onClick={() => setCreateOpen(false)}>Cancel</Button>
                    <Button type="submit" disabled={createMutation.isPending}>
                      {createMutation.isPending ? "Creating..." : "Create Member"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            )}
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-4 pb-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <Users className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold">{onlyMembers.length}</p>
              <p className="text-xs text-muted-foreground">Total Members</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
              <span className="text-sm font-bold text-blue-700">G1</span>
            </div>
            <div>
              <p className="text-2xl font-bold">{g1Count}</p>
              <p className="text-xs text-muted-foreground">Group 1 (Mon/Wed/Sat)</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4 flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-violet-100 flex items-center justify-center shrink-0">
              <span className="text-sm font-bold text-violet-700">G2</span>
            </div>
            <div>
              <p className="text-2xl font-bold">{g2Count}</p>
              <p className="text-xs text-muted-foreground">Group 2 (Tue/Thu/Sun)</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters + Table */}
      <Card>
        <CardHeader className="pb-0 pt-4 px-4 border-b">
          <div className="flex flex-col sm:flex-row gap-3 pb-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name..."
                className="pl-8"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              {(["all", "1", "2"] as const).map((g) => (
                <Button
                  key={g}
                  variant={groupFilter === g ? "default" : "outline"}
                  size="sm"
                  onClick={() => setGroupFilter(g)}
                  className="min-w-[80px]"
                >
                  {g === "all" ? "All Groups" : `Group ${g}`}
                </Button>
              ))}
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-3">
              {[1,2,3,4,5].map(i => <Skeleton key={i} className="h-16 w-full" />)}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted/50 border-b text-left">
                    <th className="px-4 py-3 font-semibold text-muted-foreground">#</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">Member</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">User ID</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">Group</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">Schedule</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground">Joined</th>
                    <th className="px-4 py-3 font-semibold text-muted-foreground text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {onlyMembers.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-4 py-12 text-center text-muted-foreground">
                        {search || groupFilter !== "all"
                          ? "No members match your search/filter."
                          : "No members yet. Add one to get started."}
                      </td>
                    </tr>
                  ) : (
                    onlyMembers.map((m, idx) => (
                      <tr key={m.id} className="hover:bg-muted/30 transition-colors" data-testid={`member-row-${m.userId}`}>
                        <td className="px-4 py-3.5 text-muted-foreground font-medium">{idx + 1}</td>
                        <td className="px-4 py-3.5">
                          <div className="flex items-center gap-3">
                            <div className={`h-9 w-9 rounded-full flex items-center justify-center text-sm font-bold shrink-0
                              ${m.group === 1 ? "bg-blue-100 text-blue-700" : "bg-violet-100 text-violet-700"}`}>
                              {m.name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <p className="font-semibold">{m.name}</p>
                              <p className="text-xs text-muted-foreground">member</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3.5">
                          <code className="text-xs bg-muted px-2 py-1 rounded font-mono">{m.userId}</code>
                        </td>
                        <td className="px-4 py-3.5">
                          <Badge
                            variant="outline"
                            className={m.group === 1
                              ? "border-blue-300 text-blue-700 bg-blue-50"
                              : "border-violet-300 text-violet-700 bg-violet-50"}
                          >
                            Group {m.group}
                          </Badge>
                        </td>
                        <td className="px-4 py-3.5 text-muted-foreground text-xs">
                          {m.group === 1 ? "Mon · Wed · Sat" : "Tue · Thu · Sun"}
                        </td>
                        <td className="px-4 py-3.5 text-muted-foreground text-xs">
                          {format(new Date(m.createdAt), "MMM d, yyyy")}
                        </td>
                        <td className="px-4 py-3.5">
                          <div className="flex items-center justify-end gap-1">
                            <ResetPasswordButton member={{ userId: m.userId, name: m.name }} />
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button
                                  variant="ghost" size="icon"
                                  className="h-8 w-8 text-muted-foreground hover:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Delete {m.name}?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    This will permanently delete <strong>{m.name}</strong> ({m.userId}) and all their attendance records. This cannot be undone.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => deleteMutation.mutate({ userId: m.userId })}
                                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                  >
                                    Delete Member
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
