import { useState } from "react";
import {
  useGetMonthlyGrid,
  getGetMonthlyGridQueryKey,
  useGetAdminStats,
  getGetAdminStatsQueryKey,
} from "@workspace/api-client-react";
import { getCurrentMonthYear, formatYearMonth } from "@/lib/date-utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronLeft, ChevronRight, Printer, TrendingUp, Users, Star } from "lucide-react";

const MONTH_NAMES = ["January","February","March","April","May","June","July","August","September","October","November","December"];

function attendanceBadge(pct: number) {
  if (pct >= 75) return <Badge className="bg-emerald-100 text-emerald-800 border border-emerald-300 hover:bg-emerald-100">Excellent</Badge>;
  if (pct >= 50) return <Badge className="bg-amber-100 text-amber-800 border border-amber-300 hover:bg-amber-100">Average</Badge>;
  return <Badge className="bg-rose-100 text-rose-800 border border-rose-300 hover:bg-rose-100">Poor</Badge>;
}

function pctColor(pct: number) {
  if (pct >= 75) return "text-emerald-600 font-bold";
  if (pct >= 50) return "text-amber-600 font-bold";
  return "text-rose-600 font-bold";
}

export default function Report() {
  const [date, setDate] = useState(() => getCurrentMonthYear());

  const gridParams = { month: date.month, year: date.year };

  const { data: grid, isLoading: gridLoading } = useGetMonthlyGrid(gridParams, {
    query: { queryKey: getGetMonthlyGridQueryKey(gridParams) },
  });

  const { data: stats, isLoading: statsLoading } = useGetAdminStats(gridParams, {
    query: { queryKey: getGetAdminStatsQueryKey(gridParams) },
  });

  const handlePrev = () => setDate(p => p.month === 1 ? { month: 12, year: p.year - 1 } : { month: p.month - 1, year: p.year });
  const handleNext = () => setDate(p => p.month === 12 ? { month: 1, year: p.year + 1 } : { month: p.month + 1, year: p.year });

  const isLoading = gridLoading || statsLoading;

  const group1Members = (grid?.members ?? [])
    .filter(m => m.group === 1)
    .sort((a, b) => b.attendancePercentage - a.attendancePercentage);

  const group2Members = (grid?.members ?? [])
    .filter(m => m.group === 2)
    .sort((a, b) => b.attendancePercentage - a.attendancePercentage);

  const allMembers = [...group1Members, ...group2Members];
  const excellentCount = allMembers.filter(m => m.attendancePercentage >= 75).length;
  const averageCount = allMembers.filter(m => m.attendancePercentage >= 50 && m.attendancePercentage < 75).length;
  const poorCount = allMembers.filter(m => m.attendancePercentage < 50).length;

  const topPerformer = allMembers.length > 0 ? allMembers.reduce((best, m) =>
    m.attendancePercentage > best.attendancePercentage ? m : best, allMembers[0]) : null;

  return (
    <div className="space-y-6" id="report-content">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Monthly Report</h2>
          <p className="text-muted-foreground text-sm">
            Full attendance breakdown by group — {formatYearMonth(date.year, date.month)}
          </p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-1 border rounded-lg p-1 bg-card">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handlePrev} data-testid="btn-report-prev">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm font-medium px-2 min-w-[130px] text-center">
              {formatYearMonth(date.year, date.month)}
            </span>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleNext} data-testid="btn-report-next">
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          <Button variant="outline" onClick={() => window.print()} data-testid="btn-print-report">
            <Printer className="h-4 w-4 mr-2" />
            Print Report
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      {isLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[1,2,3,4].map(i => <Skeleton key={i} className="h-24 w-full" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                <Users className="h-3.5 w-3.5" />
                Total Members
              </div>
              <p className="text-3xl font-bold">{allMembers.length}</p>
              <p className="text-xs text-muted-foreground mt-1">Grp1: {group1Members.length} · Grp2: {group2Members.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                <TrendingUp className="h-3.5 w-3.5" />
                Monthly Rate
              </div>
              <p className={`text-3xl ${pctColor(stats?.monthlyPresentRate ?? 0)}`}>
                {Math.round(stats?.monthlyPresentRate ?? 0)}%
              </p>
              <p className="text-xs text-muted-foreground mt-1">Overall present rate</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                <Star className="h-3.5 w-3.5 text-emerald-500" />
                Good Attendance
              </div>
              <p className="text-3xl font-bold text-emerald-600">{excellentCount}</p>
              <p className="text-xs text-muted-foreground mt-1">≥75% this month</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">
                <Star className="h-3.5 w-3.5 text-rose-500" />
                Needs Attention
              </div>
              <p className="text-3xl font-bold text-rose-600">{poorCount}</p>
              <p className="text-xs text-muted-foreground mt-1">&lt;50% this month</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Top Performer Banner */}
      {!isLoading && topPerformer && topPerformer.attendancePercentage > 0 && (
        <Card className="bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200">
          <CardContent className="py-4 flex items-center gap-4">
            <div className="h-10 w-10 rounded-full bg-emerald-500 flex items-center justify-center text-white font-bold text-lg shrink-0">
              {topPerformer.name.charAt(0)}
            </div>
            <div>
              <p className="text-xs text-emerald-700 font-medium uppercase tracking-wide">Top Performer</p>
              <p className="font-bold text-emerald-900 dark:text-emerald-100">{topPerformer.name}</p>
              <p className="text-xs text-emerald-700">Group {topPerformer.group} · {topPerformer.totalPresent}P / {topPerformer.totalAbsent}A · {Math.round(topPerformer.attendancePercentage)}% attendance</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Attendance Key */}
      <div className="flex items-center gap-4 text-sm flex-wrap">
        <span className="text-muted-foreground font-medium">Attendance Key:</span>
        <span className="flex items-center gap-1.5"><span className="h-3 w-3 rounded-full bg-emerald-500 inline-block" /> Excellent ≥75%</span>
        <span className="flex items-center gap-1.5"><span className="h-3 w-3 rounded-full bg-amber-400 inline-block" /> Average 50–74%</span>
        <span className="flex items-center gap-1.5"><span className="h-3 w-3 rounded-full bg-rose-500 inline-block" /> Poor &lt;50%</span>
      </div>

      {/* Group 1 Table */}
      <GroupTable
        title="Group 1"
        subtitle="Mon · Wed · Sat"
        members={group1Members}
        isLoading={isLoading}
        month={date.month}
        year={date.year}
        days={grid?.days ?? []}
      />

      {/* Group 2 Table */}
      <GroupTable
        title="Group 2"
        subtitle="Tue · Thu · Sun"
        members={group2Members}
        isLoading={isLoading}
        month={date.month}
        year={date.year}
        days={grid?.days ?? []}
      />

      {/* Full Summary Table */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Full Summary — All Members</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-4 space-y-2">{[1,2,3,4,5].map(i => <Skeleton key={i} className="h-10 w-full" />)}</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted/60 border-b">
                    <th className="px-4 py-3 text-left font-semibold">Rank</th>
                    <th className="px-4 py-3 text-left font-semibold">Member</th>
                    <th className="px-3 py-3 text-center font-semibold">Group</th>
                    <th className="px-3 py-3 text-center font-semibold text-emerald-700">Present</th>
                    <th className="px-3 py-3 text-center font-semibold text-rose-700">Absent</th>
                    <th className="px-3 py-3 text-center font-semibold">Attendance %</th>
                    <th className="px-3 py-3 text-center font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {allMembers.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-4 py-10 text-center text-muted-foreground">
                        No attendance data for this month.
                      </td>
                    </tr>
                  ) : (
                    allMembers.map((m, idx) => (
                      <tr key={m.userId} className={`transition-colors hover:bg-muted/40 ${m.attendancePercentage >= 75 ? "bg-emerald-50/40 dark:bg-emerald-950/10" : m.attendancePercentage < 50 && m.totalPresent + m.totalAbsent > 0 ? "bg-rose-50/40 dark:bg-rose-950/10" : ""}`}
                        data-testid={`report-row-${m.userId}`}>
                        <td className="px-4 py-3 text-muted-foreground font-medium">#{idx + 1}</td>
                        <td className="px-4 py-3">
                          <div className="font-medium">{m.name}</div>
                          <div className="text-xs text-muted-foreground">{m.userId}</div>
                        </td>
                        <td className="px-3 py-3 text-center">
                          <Badge variant="outline">Group {m.group}</Badge>
                        </td>
                        <td className="px-3 py-3 text-center font-bold text-emerald-600">{m.totalPresent}</td>
                        <td className="px-3 py-3 text-center font-bold text-rose-600">{m.totalAbsent}</td>
                        <td className={`px-3 py-3 text-center text-base ${pctColor(m.attendancePercentage)}`}>
                          {Math.round(m.attendancePercentage)}%
                        </td>
                        <td className="px-3 py-3 text-center">
                          {m.totalPresent + m.totalAbsent === 0
                            ? <Badge variant="outline" className="text-muted-foreground">No Data</Badge>
                            : attendanceBadge(m.attendancePercentage)
                          }
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function GroupTable({
  title, subtitle, members, isLoading, month, year, days
}: {
  title: string;
  subtitle: string;
  members: any[];
  isLoading: boolean;
  month: number;
  year: number;
  days: number[];
}) {
  const now = new Date();
  const isCurrentMonth = now.getMonth() + 1 === month && now.getFullYear() === year;
  const todayDay = now.getDate();

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-base">{title}</CardTitle>
            <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>
          </div>
          <div className="flex gap-2 text-sm">
            <span className="text-emerald-600 font-semibold">{members.filter(m => m.attendancePercentage >= 75).length} excellent</span>
            <span className="text-muted-foreground">/ {members.length} total</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0 overflow-x-auto">
        {isLoading ? (
          <div className="p-4 space-y-2">{[1,2,3].map(i => <Skeleton key={i} className="h-10 w-full" />)}</div>
        ) : (
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="bg-muted/50 border-b">
                <th className="px-4 py-2.5 text-left font-semibold sticky left-0 bg-muted/50 min-w-[150px]">Member</th>
                {days.map(d => (
                  <th key={d} className={`text-center text-xs font-semibold min-w-[28px] py-2.5
                    ${isCurrentMonth && d === todayDay ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>
                    {d}
                  </th>
                ))}
                <th className="px-3 py-2.5 text-center font-semibold text-emerald-700 border-l min-w-[36px]">P</th>
                <th className="px-3 py-2.5 text-center font-semibold text-rose-700 min-w-[36px]">A</th>
                <th className="px-3 py-2.5 text-center font-semibold min-w-[52px]">%</th>
                <th className="px-3 py-2.5 text-center font-semibold min-w-[90px]">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {members.length === 0 ? (
                <tr>
                  <td colSpan={days.length + 5} className="px-4 py-8 text-center text-muted-foreground">
                    No members in {title} for this month.
                  </td>
                </tr>
              ) : (
                members.map(row => (
                  <tr key={row.userId}
                    className={`hover:bg-muted/40 transition-colors
                      ${row.attendancePercentage >= 75 ? "bg-emerald-50/50 dark:bg-emerald-950/10" : ""}
                      ${row.attendancePercentage < 50 && row.totalPresent + row.totalAbsent > 0 ? "bg-rose-50/50 dark:bg-rose-950/10" : ""}
                    `}
                    data-testid={`group-row-${row.userId}`}
                  >
                    <td className="px-4 py-2.5 sticky left-0 bg-inherit border-r">
                      <div className="font-medium truncate max-w-[140px]">{row.name}</div>
                    </td>
                    {days.map(d => {
                      const status = row.attendance[String(d)];
                      return (
                        <td key={d} className={`text-center p-0.5 ${isCurrentMonth && d === todayDay ? "bg-primary/10" : ""}`}>
                          <span className={`inline-flex items-center justify-center w-6 h-7 rounded text-xs font-bold
                            ${status === "P" ? "bg-emerald-100 text-emerald-700 border border-emerald-300" : ""}
                            ${status === "A" ? "bg-rose-100 text-rose-700 border border-rose-300" : ""}
                            ${!status ? "text-muted-foreground/30" : ""}
                          `}>
                            {status || "·"}
                          </span>
                        </td>
                      );
                    })}
                    <td className="px-3 py-2.5 text-center font-bold text-emerald-600 border-l">{row.totalPresent}</td>
                    <td className="px-3 py-2.5 text-center font-bold text-rose-600">{row.totalAbsent}</td>
                    <td className={`px-3 py-2.5 text-center text-sm ${pctColor(row.attendancePercentage)}`}>
                      {Math.round(row.attendancePercentage)}%
                    </td>
                    <td className="px-3 py-2.5 text-center">
                      {row.totalPresent + row.totalAbsent === 0
                        ? <Badge variant="outline" className="text-xs text-muted-foreground">No Data</Badge>
                        : attendanceBadge(row.attendancePercentage)
                      }
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        )}
      </CardContent>
    </Card>
  );
}
