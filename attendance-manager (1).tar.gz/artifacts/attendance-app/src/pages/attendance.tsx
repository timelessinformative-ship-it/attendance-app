import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import {
  useGetMonthlyGrid,
  useMarkAttendance,
  useListMembers,
  getGetMonthlyGridQueryKey,
  getListMembersQueryKey,
  GetMonthlyGridGroup,
} from "@workspace/api-client-react";
import { formatYearMonth, getCurrentMonthYear } from "@/lib/date-utils";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronLeft, ChevronRight, CheckCircle2, XCircle, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const MONTH_NAMES = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

export default function Attendance() {
  const { member } = useAuth();
  const isAdmin = member?.role === "admin";
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const now = new Date();
  const todayDay = now.getDate();
  const todayMonth = now.getMonth() + 1;
  const todayYear = now.getFullYear();
  const todayStr = `${todayYear}-${String(todayMonth).padStart(2, "0")}-${String(todayDay).padStart(2, "0")}`;

  const [date, setDate] = useState(() => getCurrentMonthYear());
  const [group, setGroup] = useState<"all" | "1" | "2">("all");

  const isCurrentMonth = date.month === todayMonth && date.year === todayYear;

  const gridParams = {
    month: date.month,
    year: date.year,
    ...(group !== "all" ? { group: Number(group) as GetMonthlyGridGroup } : {}),
  };

  const { data: grid, isLoading } = useGetMonthlyGrid(gridParams, {
    query: { queryKey: getGetMonthlyGridQueryKey(gridParams) },
  });

  const { data: allMembers } = useListMembers(undefined, {
    query: { enabled: isAdmin, queryKey: getListMembersQueryKey() },
  });

  const [resetting, setResetting] = useState(false);

  const markMutation = useMarkAttendance({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMonthlyGridQueryKey(gridParams) });
      },
      onError: (error: any) => {
        toast({ variant: "destructive", title: "Failed to mark attendance", description: error.message });
      },
    },
  });

  const handleReset = async () => {
    setResetting(true);
    try {
      const token = localStorage.getItem("attendance_token");
      const res = await fetch(
        `/api/attendance/reset?month=${date.month}&year=${date.year}`,
        { method: "DELETE", headers: { Authorization: `Bearer ${token}` } }
      );
      if (!res.ok) throw new Error("Reset failed");
      queryClient.invalidateQueries({ queryKey: getGetMonthlyGridQueryKey(gridParams) });
      toast({ title: "Attendance reset", description: `All records for ${formatYearMonth(date.year, date.month)} have been cleared.` });
    } catch {
      toast({ variant: "destructive", title: "Reset failed", description: "Could not reset attendance." });
    } finally {
      setResetting(false);
    }
  };

  const handleMark = (userId: string, dateStr: string, status: "P" | "A") => {
    markMutation.mutate({ data: { userId, date: dateStr as any, status } });
  };

  const handleToggle = (userId: string, day: number, currentStatus: string | undefined) => {
    if (!isAdmin) return;
    const newStatus: "P" | "A" = currentStatus === "P" ? "A" : "P";
    const dateStr = `${date.year}-${String(date.month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    handleMark(userId, dateStr, newStatus);
  };

  const handlePrevMonth = () => setDate(prev =>
    prev.month === 1 ? { month: 12, year: prev.year - 1 } : { month: prev.month - 1, year: prev.year }
  );
  const handleNextMonth = () => setDate(prev =>
    prev.month === 12 ? { month: 1, year: prev.year + 1 } : { month: prev.month + 1, year: prev.year }
  );

  // Filtered members for quick mark panel (group filter)
  const filteredMembers = (allMembers ?? []).filter(m =>
    m.role === "member" && (group === "all" || String(m.group) === group)
  );

  // Get today's status for quick mark panel
  const getTodayStatus = (userId: string): string | undefined => {
    const row = grid?.members.find(r => r.userId === userId);
    return row?.attendance[String(todayDay)];
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Attendance</h2>
          <p className="text-muted-foreground text-sm">
            Today is <strong>{todayStr}</strong>
          </p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          {isAdmin && (
            <Select value={group} onValueChange={(v: any) => setGroup(v)}>
              <SelectTrigger className="w-[130px]" data-testid="select-group">
                <SelectValue placeholder="Group" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Groups</SelectItem>
                <SelectItem value="1">Group 1</SelectItem>
                <SelectItem value="2">Group 2</SelectItem>
              </SelectContent>
            </Select>
          )}
          <div className="flex items-center gap-1 border rounded-lg p-1 bg-card">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handlePrevMonth} data-testid="btn-prev-month">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm font-medium px-2 min-w-[120px] text-center">
              {formatYearMonth(date.year, date.month)}
            </span>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleNextMonth} data-testid="btn-next-month">
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          {isAdmin && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="outline"
                  className="text-destructive border-destructive/40 hover:bg-destructive/10 hover:text-destructive"
                  disabled={resetting}
                  data-testid="btn-reset-attendance"
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Reset Month
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Reset attendance for {formatYearMonth(date.year, date.month)}?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will permanently delete <strong>all attendance records</strong> for{" "}
                    <strong>{formatYearMonth(date.year, date.month)}</strong>. This cannot be undone.
                    Use this to start fresh for this month.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleReset}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    data-testid="btn-confirm-reset"
                  >
                    Yes, Reset
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>
      </div>

      {/* Quick Mark Today — admin only, current month only */}
      {isAdmin && isCurrentMonth && (
        <Card className="border-primary/20 bg-primary/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              Mark Today&apos;s Attendance
              <Badge variant="secondary">{todayStr}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!grid || !allMembers ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {[1,2,3].map(i => <Skeleton key={i} className="h-16 w-full" />)}
              </div>
            ) : filteredMembers.filter(m => m.role === "member").length === 0 ? (
              <p className="text-muted-foreground text-sm">No members match the current filter.</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {filteredMembers.map(m => {
                  const status = getTodayStatus(m.userId);
                  return (
                    <div
                      key={m.userId}
                      className="flex items-center justify-between gap-3 bg-card rounded-lg border px-4 py-3"
                      data-testid={`quick-mark-${m.userId}`}
                    >
                      <div className="min-w-0">
                        <p className="font-medium text-sm truncate">{m.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {m.userId} · Grp {m.group}
                        </p>
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <button
                          data-testid={`btn-present-${m.userId}`}
                          onClick={() => handleMark(m.userId, todayStr, "P")}
                          disabled={markMutation.isPending}
                          className={`flex items-center gap-1 px-3 py-2 rounded-md text-sm font-semibold border-2 transition-all
                            ${status === "P"
                              ? "bg-emerald-500 border-emerald-500 text-white shadow-sm"
                              : "border-emerald-300 text-emerald-700 hover:bg-emerald-50 dark:hover:bg-emerald-950"
                            }`}
                        >
                          <CheckCircle2 className="h-4 w-4" />
                          P
                        </button>
                        <button
                          data-testid={`btn-absent-${m.userId}`}
                          onClick={() => handleMark(m.userId, todayStr, "A")}
                          disabled={markMutation.isPending}
                          className={`flex items-center gap-1 px-3 py-2 rounded-md text-sm font-semibold border-2 transition-all
                            ${status === "A"
                              ? "bg-rose-500 border-rose-500 text-white shadow-sm"
                              : "border-rose-300 text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-950"
                            }`}
                        >
                          <XCircle className="h-4 w-4" />
                          A
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Monthly Grid */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">
            Monthly Grid — {MONTH_NAMES[date.month - 1]} {date.year}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          {isLoading || !grid ? (
            <div className="p-6 space-y-3">
              {[1,2,3,4].map(i => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : (
            <table className="w-full text-sm text-left border-collapse">
              <thead>
                <tr className="bg-muted/60 border-b">
                  <th className="px-4 py-3 font-semibold sticky left-0 bg-muted/60 backdrop-blur-sm z-10 min-w-[160px]">
                    Member
                  </th>
                  {grid.days.map(day => {
                    const isToday = isCurrentMonth && day === todayDay;
                    return (
                      <th
                        key={day}
                        className={`py-3 font-semibold text-center min-w-[36px] text-xs
                          ${isToday ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
                      >
                        {day}
                      </th>
                    );
                  })}
                  <th className="px-3 py-3 font-semibold text-center text-emerald-700 border-l min-w-[40px]">P</th>
                  <th className="px-3 py-3 font-semibold text-center text-rose-700 min-w-[40px]">A</th>
                  <th className="px-3 py-3 font-semibold text-center text-muted-foreground min-w-[48px]">%</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {grid.members.length === 0 ? (
                  <tr>
                    <td colSpan={grid.days.length + 4} className="px-4 py-10 text-center text-muted-foreground">
                      No members found.
                    </td>
                  </tr>
                ) : (
                  grid.members.map(row => (
                    <tr key={row.userId} className="hover:bg-muted/40 transition-colors group">
                      <td className="px-4 py-2 sticky left-0 bg-card group-hover:bg-muted/40 transition-colors z-10 border-r">
                        <div className="font-medium truncate max-w-[160px]" title={row.name}>
                          {row.name}
                        </div>
                        <div className="text-xs text-muted-foreground">Grp {row.group}</div>
                      </td>

                      {grid.days.map(day => {
                        // Key is the day number as string e.g. "6"
                        const status = row.attendance[String(day)];
                        const isToday = isCurrentMonth && day === todayDay;

                        return (
                          <td
                            key={day}
                            className={`text-center p-0.5 ${isToday ? "bg-primary/10" : ""}`}
                          >
                            <button
                              data-testid={`cell-${row.userId}-${day}`}
                              disabled={!isAdmin}
                              onClick={() => handleToggle(row.userId, day, status)}
                              title={isAdmin ? `Click to toggle attendance for day ${day}` : undefined}
                              className={`w-8 h-9 rounded text-xs font-bold mx-auto flex items-center justify-center transition-all
                                ${isAdmin ? "cursor-pointer hover:opacity-80 active:scale-95" : "cursor-default"}
                                ${status === "P" ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300 border border-emerald-300" : ""}
                                ${status === "A" ? "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300 border border-rose-300" : ""}
                                ${!status ? "text-muted-foreground/30 hover:bg-muted/50" : ""}
                              `}
                            >
                              {status || (isAdmin ? "·" : "")}
                            </button>
                          </td>
                        );
                      })}

                      <td className="px-3 py-2 text-center font-bold text-emerald-600 border-l">{row.totalPresent}</td>
                      <td className="px-3 py-2 text-center font-bold text-rose-600">{row.totalAbsent}</td>
                      <td className="px-3 py-2 text-center font-semibold">{Math.round(row.attendancePercentage)}%</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>

      {/* Legend */}
      {isAdmin && (
        <p className="text-xs text-muted-foreground text-center">
          Click any cell in the grid to toggle between <span className="text-emerald-600 font-semibold">P</span> (Present) and <span className="text-rose-600 font-semibold">A</span> (Absent).
        </p>
      )}
    </div>
  );
}
