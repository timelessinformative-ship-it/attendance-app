import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { getCurrentMonthYear, formatYearMonth } from "@/lib/date-utils";
import { getExportAttendanceCsvUrl } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download } from "lucide-react";

export default function Export() {
  const [date, setDate] = useState(() => getCurrentMonthYear());
  const [group, setGroup] = useState<"all" | "1" | "2">("all");

  const handleExport = () => {
    const params = {
      month: date.month,
      year: date.year,
      ...(group !== "all" ? { group: Number(group) } : {})
    };

    // Assuming customFetch uses the token, but for a direct download link we might need to 
    // fetch the blob and then trigger download manually, or if the API handles auth via cookie 
    // we could just open the URL. Since it's token-based in localStorage, we should fetch it.
    const token = localStorage.getItem("attendance_token");
    const url = getExportAttendanceCsvUrl(params);
    const fullUrl = url.startsWith("http") ? url : `${window.location.origin}${url}`;

    fetch(fullUrl, {
      headers: {
        "Authorization": `Bearer ${token}`
      }
    })
    .then(res => {
      if (!res.ok) throw new Error("Failed to export");
      return res.blob();
    })
    .then(blob => {
      const blobUrl = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = blobUrl;
      const groupStr = group !== "all" ? `_Group${group}` : "";
      a.download = `Attendance_${date.year}_${date.month}${groupStr}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(blobUrl);
      document.body.removeChild(a);
    })
    .catch(err => {
      console.error(err);
      alert("Failed to export data");
    });
  };

  const months = Array.from({ length: 12 }, (_, i) => i + 1);
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => currentYear - i);

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Export Data</h2>
        <p className="text-muted-foreground">Download attendance records as CSV.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Monthly Report</CardTitle>
          <CardDescription>Select the month, year, and group to generate a report.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Month</label>
              <Select 
                value={date.month.toString()} 
                onValueChange={(v) => setDate(prev => ({ ...prev, month: parseInt(v) }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {months.map(m => (
                    <SelectItem key={m} value={m.toString()}>
                      {formatYearMonth(2000, m).split(" ")[0]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Year</label>
              <Select 
                value={date.year.toString()} 
                onValueChange={(v) => setDate(prev => ({ ...prev, year: parseInt(v) }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {years.map(y => (
                    <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Group Filter</label>
            <Select value={group} onValueChange={(val: any) => setGroup(val)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Groups</SelectItem>
                <SelectItem value="1">Group 1</SelectItem>
                <SelectItem value="2">Group 2</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button onClick={handleExport} className="w-full">
            <Download className="mr-2 h-4 w-4" />
            Download CSV
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
