import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { LogOut, LayoutDashboard, CalendarDays, Users, Download, Menu, FileBarChart2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";

export function Layout({ children }: { children: React.ReactNode }) {
  const { member, logout } = useAuth();
  const [location] = useLocation();
  const [open, setOpen] = useState(false);

  const navigation = [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard, adminOnly: false },
    { name: "Attendance", href: "/attendance", icon: CalendarDays, adminOnly: false },
    { name: "Members", href: "/members", icon: Users, adminOnly: true },
    { name: "Report", href: "/report", icon: FileBarChart2, adminOnly: true },
    { name: "Export", href: "/export", icon: Download, adminOnly: true },
  ];

  const filteredNav = navigation.filter(item => !item.adminOnly || member?.role === "admin");

  const NavLinks = () => (
    <div className="flex flex-col gap-1">
      {filteredNav.map((item) => {
        const isActive = location === item.href;
        return (
          <Link key={item.name} href={item.href}>
            <Button
              variant={isActive ? "secondary" : "ghost"}
              className={`w-full justify-start ${isActive ? "bg-secondary" : ""}`}
              onClick={() => setOpen(false)}
            >
              <item.icon className="mr-2 h-4 w-4" />
              {item.name}
            </Button>
          </Link>
        );
      })}
    </div>
  );

  return (
    <div className="min-h-screen flex w-full bg-background text-foreground">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex w-64 flex-col border-r bg-card">
        <div className="p-4 border-b h-16 flex items-center">
          <h1 className="font-bold text-lg">Attendance</h1>
        </div>
        <div className="flex-1 overflow-auto py-4 px-3">
          <NavLinks />
        </div>
        <div className="p-4 border-t">
          <div className="flex flex-col mb-4">
            <span className="font-medium text-sm">{member?.name}</span>
            <span className="text-xs text-muted-foreground capitalize">{member?.role} • Group {member?.group}</span>
          </div>
          <Button variant="outline" className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10" onClick={logout}>
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </aside>

      {/* Mobile Header & Content */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="md:hidden h-16 border-b flex items-center px-4 bg-card justify-between sticky top-0 z-10">
          <h1 className="font-bold text-lg">Attendance</h1>
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0 flex flex-col">
              <div className="p-4 border-b h-16 flex items-center">
                <h1 className="font-bold text-lg">Attendance</h1>
              </div>
              <div className="flex-1 overflow-auto py-4 px-3">
                <NavLinks />
              </div>
              <div className="p-4 border-t">
                <div className="flex flex-col mb-4">
                  <span className="font-medium text-sm">{member?.name}</span>
                  <span className="text-xs text-muted-foreground capitalize">{member?.role} • Group {member?.group}</span>
                </div>
                <Button variant="outline" className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10" onClick={() => { logout(); setOpen(false); }}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </header>

        <main className="flex-1 overflow-auto p-4 md:p-6 lg:p-8 bg-muted/10">
          <div className="mx-auto max-w-6xl">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
