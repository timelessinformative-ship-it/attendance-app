import { Router, Request, Response } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, signToken, AuthPayload } from "../middlewares/auth";
import { LoginBody } from "@workspace/api-zod";

const router = Router();

router.post("/login", async (req: Request, res: Response) => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const { userId, password } = parsed.data;

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.userId, userId))
    .limit(1);

  if (!user) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  const token = signToken({ userId: user.userId, role: user.role, group: user.group });

  res.json({
    token,
    member: {
      id: user.id,
      userId: user.userId,
      name: user.name,
      role: user.role,
      group: user.group,
      createdAt: user.createdAt,
    },
  });
});

router.get("/me", requireAuth, async (req: Request, res: Response) => {
  const user = (req as Request & { user: AuthPayload }).user;

  const [dbUser] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.userId, user.userId))
    .limit(1);

  if (!dbUser) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json({
    id: dbUser.id,
    userId: dbUser.userId,
    name: dbUser.name,
    role: dbUser.role,
    group: dbUser.group,
    createdAt: dbUser.createdAt,
  });
});

export default router;
