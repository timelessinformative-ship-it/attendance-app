import { Router, Request, Response } from "express";
import { db, attendanceTable, usersTable } from "@workspace/db";
import { eq, and, gte, lte, count } from "drizzle-orm";
import { requireAuth, requireAdmin, AuthPayload } from "../middlewares/auth";
import { GetAdminStatsQueryParams, GetMemberStatsQueryParams } from "@workspace/api-zod";

const router = Router();

const GROUP_DAYS: Record<number, number[]> = {
  1: [1, 3, 6], // Mon, Wed, Sat
  2: [2, 4, 0], // Tue, Thu, Sun
};

function getDaysInMonth(month: number, year: number): number[] {
  const days = new Date(year, month, 0).getDate();
  return Array.from({ length: days }, (_, i) => i + 1);
}

function getScheduledDays(group: number, month: number, year: number): number[] {
  const groupDays = GROUP_DAYS[group] ?? [];
  return getDaysInMonth(month, year).filter((d) => {
    const date = new Date(year, month - 1, d);
    return groupDays.includes(date.getDay());
  });
}

router.get("/admin-stats", requireAuth, requireAdmin, async (req: Request, res: Response) => {
  const parsed = GetAdminStatsQueryParams.safeParse(req.query);
  const now = new Date();
  const month = parsed.success && parsed.data.month ? Number(parsed.data.month) : now.getMonth() + 1;
  const year = parsed.success && parsed.data.year ? Number(parsed.data.year) : now.getFullYear();

  const startDate = `${year}-${String(month).padStart(2, "0")}-01`;
  const endDate = `${year}-${String(month).padStart(2, "0")}-${String(new Date(year, month, 0).getDate()).padStart(2, "0")}`;

  const [{ total }] = await db.select({ total: count() }).from(usersTable);
  const [{ g1 }] = await db
    .select({ g1: count() })
    .from(usersTable)
    .where(and(eq(usersTable.group, 1), eq(usersTable.role, "member")));
  const [{ g2 }] = await db
    .select({ g2: count() })
    .from(usersTable)
    .where(and(eq(usersTable.group, 2), eq(usersTable.role, "member")));

  const todayStr = now.toISOString().split("T")[0];
  const todayRecords = await db
    .select()
    .from(attendanceTable)
    .where(eq(attendanceTable.date, todayStr));

  const todayPresent = todayRecords.filter((r) => r.status === "P").length;
  const todayAbsent = todayRecords.filter((r) => r.status === "A").length;

  // Today's scheduled count
  const todayDow = now.getDay();
  const g1Members = Number(g1);
  const g2Members = Number(g2);
  const g1ScheduledToday = GROUP_DAYS[1].includes(todayDow) ? g1Members : 0;
  const g2ScheduledToday = GROUP_DAYS[2].includes(todayDow) ? g2Members : 0;
  const totalScheduledToday = g1ScheduledToday + g2ScheduledToday;

  const monthRecords = await db
    .select()
    .from(attendanceTable)
    .where(and(gte(attendanceTable.date, startDate), lte(attendanceTable.date, endDate)));

  const monthPresent = monthRecords.filter((r) => r.status === "P").length;
  const monthTotal = monthRecords.length;
  const monthlyPresentRate = monthTotal > 0 ? Math.round((monthPresent / monthTotal) * 100) : 0;

  // Group-level present rates
  const allMembers = await db.select().from(usersTable).where(eq(usersTable.role, "member"));

  let g1Present = 0, g1Total = 0, g2Present = 0, g2Total = 0;
  const leaderboard: Array<{
    userId: string;
    name: string;
    group: number;
    attendancePercentage: number;
    totalPresent: number;
    totalScheduled: number;
  }> = [];

  for (const member of allMembers) {
    const memberRecords = monthRecords.filter((r) => r.userId === member.userId);
    const present = memberRecords.filter((r) => r.status === "P").length;
    const scheduledDays = getScheduledDays(member.group, month, year);
    // Only count scheduled days up to today for current month
    const isCurrentMonth = month === now.getMonth() + 1 && year === now.getFullYear();
    const effectiveScheduled = isCurrentMonth
      ? scheduledDays.filter((d) => d <= now.getDate()).length
      : scheduledDays.length;
    const pct = effectiveScheduled > 0 ? Math.round((present / effectiveScheduled) * 100) : 0;

    leaderboard.push({
      userId: member.userId,
      name: member.name,
      group: member.group,
      attendancePercentage: pct,
      totalPresent: present,
      totalScheduled: effectiveScheduled,
    });

    if (member.group === 1) { g1Present += present; g1Total += effectiveScheduled; }
    if (member.group === 2) { g2Present += present; g2Total += effectiveScheduled; }
  }

  leaderboard.sort((a, b) => b.attendancePercentage - a.attendancePercentage);
  const group1PresentRate = g1Total > 0 ? Math.round((g1Present / g1Total) * 100) : 0;
  const group2PresentRate = g2Total > 0 ? Math.round((g2Present / g2Total) * 100) : 0;

  const allDays = getDaysInMonth(month, year);
  const trendMap: Record<string, { present: number; absent: number }> = {};
  allDays.forEach((d) => {
    const dateStr = `${year}-${String(month).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    trendMap[dateStr] = { present: 0, absent: 0 };
  });

  monthRecords.forEach((r) => {
    if (trendMap[r.date]) {
      if (r.status === "P") trendMap[r.date].present++;
      else trendMap[r.date].absent++;
    }
  });

  const monthlyTrend = Object.entries(trendMap).map(([date, v]) => ({
    date,
    present: v.present,
    absent: v.absent,
  }));

  const memberTotal = Number(total) - 1;

  res.json({
    totalMembers: memberTotal > 0 ? memberTotal : 0,
    group1Count: g1Members,
    group2Count: g2Members,
    monthlyPresentRate,
    group1PresentRate,
    group2PresentRate,
    todayPresent,
    todayAbsent,
    totalScheduledToday,
    monthlyTrend,
    leaderboard,
  });
});

router.get("/member-stats", requireAuth, async (req: Request, res: Response) => {
  const authUser = (req as Request & { user: AuthPayload }).user;
  const parsed = GetMemberStatsQueryParams.safeParse(req.query);
  const now = new Date();
  const month = parsed.success && parsed.data.month ? Number(parsed.data.month) : now.getMonth() + 1;
  const year = parsed.success && parsed.data.year ? Number(parsed.data.year) : now.getFullYear();

  const startDate = `${year}-${String(month).padStart(2, "0")}-01`;
  const endDate = `${year}-${String(month).padStart(2, "0")}-${String(new Date(year, month, 0).getDate()).padStart(2, "0")}`;

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.userId, authUser.userId))
    .limit(1);

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  const scheduledDays = getScheduledDays(user.group, month, year);

  const records = await db
    .select()
    .from(attendanceTable)
    .where(
      and(
        eq(attendanceTable.userId, authUser.userId),
        gte(attendanceTable.date, startDate),
        lte(attendanceTable.date, endDate)
      )
    );

  const totalPresent = records.filter((r) => r.status === "P").length;
  const totalAbsent = records.filter((r) => r.status === "A").length;
  const totalScheduled = scheduledDays.length;
  const attendancePercentage =
    totalScheduled > 0 ? Math.round((totalPresent / totalScheduled) * 100) : 0;

  const monthlyBreakdown = records.map((r) => ({
    date: r.date,
    status: r.status as "P" | "A",
  }));

  res.json({
    userId: user.userId,
    name: user.name,
    group: user.group,
    totalPresent,
    totalAbsent,
    totalScheduled,
    attendancePercentage,
    monthlyBreakdown,
  });
});

export default router;
