import { Router, Request, Response } from "express";
import { db, attendanceTable, usersTable } from "@workspace/db";
import { eq, and, gte, lte, sql } from "drizzle-orm";
import { requireAuth, requireAdmin, AuthPayload } from "../middlewares/auth";
import {
  MarkAttendanceBody,
  UpdateAttendanceBody,
  UpdateAttendanceParams,
  ListAttendanceQueryParams,
  GetMonthlyGridQueryParams,
  ExportAttendanceCsvQueryParams,
} from "@workspace/api-zod";

const router = Router();

// Group schedules
const GROUP_DAYS: Record<number, number[]> = {
  1: [1, 3, 6], // Mon=1, Wed=3, Sat=6
  2: [2, 4, 0], // Tue=2, Thu=4, Sun=0
};

function getDaysInMonth(month: number, year: number): number[] {
  const days = new Date(year, month, 0).getDate();
  return Array.from({ length: days }, (_, i) => i + 1);
}

function getGroupDaysInMonth(month: number, year: number, group: number): number[] {
  const groupDays = GROUP_DAYS[group] ?? [];
  return getDaysInMonth(month, year).filter((day) => {
    const date = new Date(year, month - 1, day);
    return groupDays.includes(date.getDay());
  });
}

router.get("/monthly-grid", requireAuth, async (req: Request, res: Response) => {
  const authUser = (req as Request & { user: AuthPayload }).user;
  const parsed = GetMonthlyGridQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid query params" });
    return;
  }

  const { month, year, group } = parsed.data;
  const m = Number(month);
  const y = Number(year);

  const startDate = `${y}-${String(m).padStart(2, "0")}-01`;
  const endDate = `${y}-${String(m).padStart(2, "0")}-${String(new Date(y, m, 0).getDate()).padStart(2, "0")}`;

  let usersQuery = db.select().from(usersTable).$dynamic();
  if (group) {
    usersQuery = usersQuery.where(eq(usersTable.group, Number(group)));
  }

  let users = await usersQuery;

  // Members see only themselves
  if (authUser.role !== "admin") {
    users = users.filter((u) => u.userId === authUser.userId);
  }

  const records = await db
    .select()
    .from(attendanceTable)
    .where(and(gte(attendanceTable.date, startDate), lte(attendanceTable.date, endDate)));

  const allDays = getDaysInMonth(m, y);

  const memberRows = users.map((u) => {
    const userRecords = records.filter((r) => r.userId === u.userId);
    const attendance: Record<string, string> = {};
    userRecords.forEach((r) => {
      const day = parseInt(r.date.split("-")[2]);
      attendance[day] = r.status;
    });

    const groupDays = getGroupDaysInMonth(m, y, u.group);
    const totalPresent = userRecords.filter((r) => r.status === "P").length;
    const totalAbsent = userRecords.filter((r) => r.status === "A").length;
    const totalScheduled = groupDays.length;
    const attendancePercentage =
      totalScheduled > 0 ? Math.round((totalPresent / totalScheduled) * 100) : 0;

    return {
      userId: u.userId,
      name: u.name,
      group: u.group,
      attendance,
      totalPresent,
      totalAbsent,
      attendancePercentage,
    };
  });

  res.json({ month: m, year: y, days: allDays, members: memberRows });
});

router.get("/export", requireAuth, requireAdmin, async (req: Request, res: Response) => {
  const parsed = ExportAttendanceCsvQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid query params" });
    return;
  }

  const { month, year, group } = parsed.data;
  const m = Number(month);
  const y = Number(year);

  const startDate = `${y}-${String(m).padStart(2, "0")}-01`;
  const endDate = `${y}-${String(m).padStart(2, "0")}-${String(new Date(y, m, 0).getDate()).padStart(2, "0")}`;

  let usersQuery = db.select().from(usersTable).$dynamic();
  if (group) {
    usersQuery = usersQuery.where(eq(usersTable.group, Number(group)));
  }
  const users = await usersQuery;

  const records = await db
    .select()
    .from(attendanceTable)
    .where(and(gte(attendanceTable.date, startDate), lte(attendanceTable.date, endDate)));

  const allDays = getDaysInMonth(m, y);
  const header = ["Name", "User ID", "Group", ...allDays.map((d) => `Day ${d}`), "Total P", "Total A", "Attendance %"];

  const rows = users.map((u) => {
    const userRecords = records.filter((r) => r.userId === u.userId);
    const attendance: Record<number, string> = {};
    userRecords.forEach((r) => {
      const day = parseInt(r.date.split("-")[2]);
      attendance[day] = r.status;
    });

    const groupDays = getGroupDaysInMonth(m, y, u.group);
    const totalPresent = userRecords.filter((r) => r.status === "P").length;
    const totalAbsent = userRecords.filter((r) => r.status === "A").length;
    const totalScheduled = groupDays.length;
    const pct = totalScheduled > 0 ? Math.round((totalPresent / totalScheduled) * 100) : 0;

    const dayCells = allDays.map((d) => attendance[d] ?? "");
    return [u.name, u.userId, u.group, ...dayCells, totalPresent, totalAbsent, `${pct}%`];
  });

  const csvLines = [header, ...rows].map((row) => row.join(",")).join("\n");

  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename=attendance-${y}-${m}.csv`);
  res.send(csvLines);
});

router.delete("/reset", requireAuth, requireAdmin, async (req: Request, res: Response) => {
  const month = Number(req.query.month);
  const year = Number(req.query.year);

  if (!month || !year || month < 1 || month > 12 || year < 2000) {
    res.status(400).json({ error: "Valid month and year are required" });
    return;
  }

  const startDate = `${year}-${String(month).padStart(2, "0")}-01`;
  const endDate = `${year}-${String(month).padStart(2, "0")}-${String(new Date(year, month, 0).getDate()).padStart(2, "0")}`;

  await db
    .delete(attendanceTable)
    .where(and(gte(attendanceTable.date, startDate), lte(attendanceTable.date, endDate)));

  res.json({ success: true, message: `Attendance reset for ${month}/${year}` });
});

router.get("/", requireAuth, async (req: Request, res: Response) => {
  const authUser = (req as Request & { user: AuthPayload }).user;
  const parsed = ListAttendanceQueryParams.safeParse(req.query);
  const { userId, month, year } = parsed.success ? parsed.data : {};

  const targetUserId = authUser.role === "admin" ? userId : authUser.userId;

  const conditions = [];
  if (targetUserId) {
    conditions.push(eq(attendanceTable.userId, targetUserId));
  }
  if (month && year) {
    const m = Number(month);
    const y = Number(year);
    const startDate = `${y}-${String(m).padStart(2, "0")}-01`;
    const endDate = `${y}-${String(m).padStart(2, "0")}-${String(new Date(y, m, 0).getDate()).padStart(2, "0")}`;
    conditions.push(gte(attendanceTable.date, startDate));
    conditions.push(lte(attendanceTable.date, endDate));
  }

  let query = db
    .select({
      id: attendanceTable.id,
      userId: attendanceTable.userId,
      date: attendanceTable.date,
      status: attendanceTable.status,
      memberName: usersTable.name,
    })
    .from(attendanceTable)
    .leftJoin(usersTable, eq(attendanceTable.userId, usersTable.userId))
    .$dynamic();

  if (conditions.length > 0) {
    query = query.where(and(...conditions));
  }

  const records = await query;

  res.json(
    records.map((r) => ({
      id: r.id,
      userId: r.userId,
      memberName: r.memberName ?? "",
      date: r.date,
      status: r.status,
    }))
  );
});

router.post("/", requireAuth, requireAdmin, async (req: Request, res: Response) => {
  const parsed = MarkAttendanceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const { userId, date, status } = parsed.data;

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.userId, userId))
    .limit(1);

  if (!user) {
    res.status(404).json({ error: "Member not found" });
    return;
  }

  const [record] = await db
    .insert(attendanceTable)
    .values({ userId, date, status })
    .onConflictDoUpdate({
      target: [attendanceTable.userId, attendanceTable.date],
      set: { status },
    })
    .returning();

  res.json({
    id: record.id,
    userId: record.userId,
    memberName: user.name,
    date: record.date,
    status: record.status,
  });
});

router.put("/:id", requireAuth, requireAdmin, async (req: Request, res: Response) => {
  const paramsParsed = UpdateAttendanceParams.safeParse(req.params);
  const bodyParsed = UpdateAttendanceBody.safeParse(req.body);

  if (!paramsParsed.success || !bodyParsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }

  const { id } = paramsParsed.data;
  const { status } = bodyParsed.data;

  const [existing] = await db
    .select()
    .from(attendanceTable)
    .where(eq(attendanceTable.id, Number(id)))
    .limit(1);

  if (!existing) {
    res.status(404).json({ error: "Record not found" });
    return;
  }

  const [updated] = await db
    .update(attendanceTable)
    .set({ status })
    .where(eq(attendanceTable.id, Number(id)))
    .returning();

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.userId, updated.userId))
    .limit(1);

  res.json({
    id: updated.id,
    userId: updated.userId,
    memberName: user?.name ?? "",
    date: updated.date,
    status: updated.status,
  });
});

export default router;
