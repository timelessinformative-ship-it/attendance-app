import { Router, Request, Response } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable } from "@workspace/db";
import { eq, ilike, and } from "drizzle-orm";
import { requireAuth, requireAdmin, AuthPayload } from "../middlewares/auth";
import { CreateMemberBody, ListMembersQueryParams } from "@workspace/api-zod";

const router = Router();

function generateUserId(): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `USR-${timestamp}-${random}`;
}

function generatePassword(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
  let password = "";
  for (let i = 0; i < 10; i++) {
    password += chars[Math.floor(Math.random() * chars.length)];
  }
  return password;
}

router.get("/", requireAuth, requireAdmin, async (req: Request, res: Response) => {
  const parsed = ListMembersQueryParams.safeParse(req.query);
  const { search, group } = parsed.success ? parsed.data : {};

  let query = db.select().from(usersTable).$dynamic();

  const conditions = [];
  if (search) {
    conditions.push(ilike(usersTable.name, `%${search}%`));
  }
  if (group) {
    conditions.push(eq(usersTable.group, Number(group)));
  }

  if (conditions.length > 0) {
    query = query.where(and(...conditions));
  }

  const users = await query;

  res.json(
    users.map((u) => ({
      id: u.id,
      userId: u.userId,
      name: u.name,
      role: u.role,
      group: u.group,
      createdAt: u.createdAt,
    }))
  );
});

router.post("/", requireAuth, requireAdmin, async (req: Request, res: Response) => {
  const parsed = CreateMemberBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const { name, group } = parsed.data;
  const userId = generateUserId();
  const plainPassword = generatePassword();
  const passwordHash = await bcrypt.hash(plainPassword, 10);

  const [user] = await db
    .insert(usersTable)
    .values({ userId, name, passwordHash, role: "member", group: Number(group) })
    .returning();

  res.status(201).json({
    id: user.id,
    userId: user.userId,
    name: user.name,
    role: user.role,
    group: user.group,
    createdAt: user.createdAt,
    plainPassword,
  });
});

router.get("/:userId", requireAuth, async (req: Request, res: Response) => {
  const authUser = (req as Request & { user: AuthPayload }).user;
  const { userId } = req.params;

  if (authUser.role !== "admin" && authUser.userId !== userId) {
    res.status(403).json({ error: "Access denied" });
    return;
  }

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.userId, userId))
    .limit(1);

  if (!user) {
    res.status(404).json({ error: "Member not found" });
    return;
  }

  res.json({
    id: user.id,
    userId: user.userId,
    name: user.name,
    role: user.role,
    group: user.group,
    createdAt: user.createdAt,
  });
});

router.put("/:userId/password", requireAuth, requireAdmin, async (req: Request, res: Response) => {
  const { userId } = req.params;

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.userId, userId))
    .limit(1);

  if (!user) {
    res.status(404).json({ error: "Member not found" });
    return;
  }

  if (user.role === "admin") {
    res.status(400).json({ error: "Cannot reset admin password via this endpoint" });
    return;
  }

  const plainPassword = generatePassword();
  const passwordHash = await bcrypt.hash(plainPassword, 10);

  await db.update(usersTable).set({ passwordHash }).where(eq(usersTable.userId, userId));

  res.json({
    id: user.id,
    userId: user.userId,
    name: user.name,
    role: user.role,
    group: user.group,
    createdAt: user.createdAt,
    plainPassword,
  });
});

router.delete("/:userId", requireAuth, requireAdmin, async (req: Request, res: Response) => {
  const { userId } = req.params;

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.userId, userId))
    .limit(1);

  if (!user) {
    res.status(404).json({ error: "Member not found" });
    return;
  }

  if (user.role === "admin") {
    res.status(400).json({ error: "Cannot delete admin account" });
    return;
  }

  await db.delete(usersTable).where(eq(usersTable.userId, userId));

  res.json({ success: true, message: "Member deleted successfully" });
});

export default router;
