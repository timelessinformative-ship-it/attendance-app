import { pgTable, serial, text, date, unique } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const attendanceTable = pgTable(
  "attendance",
  {
    id: serial("id").primaryKey(),
    userId: text("user_id").notNull(),
    date: date("date").notNull(),
    status: text("status", { enum: ["P", "A"] }).notNull(),
  },
  (t) => [unique("attendance_user_date_unique").on(t.userId, t.date)],
);

export const insertAttendanceSchema = createInsertSchema(attendanceTable).omit({
  id: true,
});

export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Attendance = typeof attendanceTable.$inferSelect;
